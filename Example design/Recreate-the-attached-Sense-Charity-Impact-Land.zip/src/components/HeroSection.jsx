import React from 'react';
import { useRevealOnScroll } from '../hooks/useRevealOnScroll';
import HeroMediaCard from './HeroMediaCard';

const deepShadow =
  '0 2.8px 2.2px rgba(0,0,0,0.034), 0 6.7px 5.3px rgba(0,0,0,0.048), 0 12.5px 10px rgba(0,0,0,0.06), 0 22.3px 17.9px rgba(0,0,0,0.072), 0 41.8px 33.4px rgba(0,0,0,0.086), 0 100px 80px rgba(0,0,0,0.12)';

export default function HeroSection() {
  const { ref, revealed } = useRevealOnScroll(0.1);

  const animClass = (delay = '') =>
    `transition-all duration-700 ease-out ${delay} ${revealed ? 'opacity-100 translate-y-0 blur-0' : 'opacity-0 translate-y-8 blur-md'}`;

  return (
    <section className="sm:px-8 max-w-7xl mr-auto ml-auto pr-6 pb-16 pl-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-14 items-center">
        {/* Left: Copy */}
        <div className="max-w-xl" ref={ref}>
          {/* Social proof */}
          <div className={animClass()}>
            <div className="flex gap-3 mb-6 items-center">
              <div className="flex -space-x-2">
                <img className="ring-2 ring-white w-7 h-7 object-cover rounded-full" src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/5aa0d46a-9a98-4044-bce9-68ec849538ef_320w.jpg" alt="Member avatar 1" />
                <img className="w-7 h-7 object-cover ring-white ring-2 rounded-full" src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/a847bbaa-3964-40c8-ad91-98b3d6429867_320w.jpg" alt="Member avatar 2" />
                <img className="w-7 h-7 object-cover ring-white ring-2 rounded-full" src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/054cd9f9-ea66-4ac7-8e45-659730cfc5a3_320w.jpg" alt="Member avatar 3" />
              </div>
              <p className="text-sm text-neutral-600 font-geist">
                <span className="font-medium text-neutral-900 font-geist">1000+</span> donor active members
              </p>
            </div>
          </div>

          {/* Headline */}
          <h1 className={`sm:text-5xl lg:text-[64px] leading-[1.05] text-4xl font-medium tracking-tighter font-geist mb-6 ${animClass('delay-150')}`}>
            Sense for a brighter future
          </h1>

          <p className={`sm:text-lg leading-relaxed text-base text-neutral-600 font-geist mb-8 ${animClass('delay-300')}`}>
            Join Sense to create tangible impact across communities worldwide. Your support brings hope, resources, and opportunity.
          </p>

          {/* CTAs */}
          <div className={`flex items-center gap-5 mb-12 ${animClass('delay-[450ms]')}`}>
            <a
              href="#"
              className="group inline-flex items-center hover:bg-neutral-800 transition-colors font-medium text-white bg-neutral-900 rounded-full pt-3 pr-3 pb-3 pl-6"
              style={{ boxShadow: deepShadow }}
            >
              <span className="font-geist">Donate Now</span>
              <span className="ml-3 inline-flex items-center justify-center h-8 w-8 rounded-full bg-white/10 ring-1 ring-white/15 group-hover:bg-white/15">
                <iconify-icon icon="solar:arrow-right-linear" width="16" height="16"></iconify-icon>
              </span>
            </a>
            <a href="#" className="inline-flex items-center gap-2 text-neutral-900 font-medium hover:opacity-80 font-geist">
              Learn More
              <iconify-icon icon="solar:play-linear" width="16" height="16"></iconify-icon>
            </a>
          </div>

          {/* Partners */}
          <div className={animClass('delay-[600ms]')}>
            <p className="text-sm text-neutral-500 font-geist mb-4">Our most loved partners</p>
            <div className="flex gap-6 sm:gap-10 items-center">
              <a href="#" className="inline-flex items-center justify-center bg-center mix-blend-multiply w-[100px] h-[40px] bg-cover rounded invert" style={{ backgroundImage: 'url(https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/ffc4abed-7f85-4259-810c-a0223b0bd624_320w.jpg)' }}></a>
              <a href="#" className="inline-flex items-center justify-center bg-center mix-blend-multiply w-[100px] h-[40px] bg-cover rounded invert" style={{ backgroundImage: 'url(https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/570e9153-7c3d-4273-9119-04a156b424ab_320w.jpg)' }}></a>
              <a href="#" className="inline-flex items-center justify-center bg-center mix-blend-multiply w-[100px] h-[40px] bg-cover rounded invert" style={{ backgroundImage: 'url(https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/7808c442-c8f8-4c6b-bea1-00daffbaea4d_320w.jpg)' }}></a>
            </div>
          </div>
        </div>

        {/* Right: Media card */}
        <HeroMediaCard />
      </div>
    </section>
  );
}