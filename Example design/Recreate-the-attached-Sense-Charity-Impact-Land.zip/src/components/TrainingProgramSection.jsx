import React from 'react';
import { useRevealOnScroll } from '../hooks/useRevealOnScroll';

const deepShadow =
  '0 2.8px 2.2px rgba(0,0,0,0.034), 0 6.7px 5.3px rgba(0,0,0,0.048), 0 12.5px 10px rgba(0,0,0,0.06), 0 22.3px 17.9px rgba(0,0,0,0.072), 0 41.8px 33.4px rgba(0,0,0,0.086), 0 100px 80px rgba(0,0,0,0.12)';

const cards = [
  {
    img: 'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/e202b3bf-44a7-4067-870b-90bf6761a2da_800w.jpg',
    alt: 'Community volunteer training',
    title: 'Hands-on training',
    desc: 'Learn directly from experienced humanitarian workers and community leaders worldwide.',
  },
  {
    img: 'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/03a90f56-64e4-4b02-9e04-1bb0f51de74c_800w.jpg',
    alt: 'Impact measurement workshop',
    title: 'Impact measurement',
    desc: 'Master the tools and techniques to track, measure, and amplify your charitable impact.',
  },
  {
    img: 'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/ede50f82-0ad0-4579-a4ae-3a942856d03b_800w.jpg',
    alt: 'Global changemaker network',
    title: 'Global network',
    desc: 'Connect with passionate changemakers, share experiences, and collaborate on projects.',
  },
];

const stats = [
  { value: '12', label: 'training modules' },
  { value: '500+', label: 'trained volunteers' },
  { value: '50+', label: 'countries reached' },
  { value: 'Free', label: 'for all members' },
];

export default function TrainingProgramSection() {
  const { ref, revealed } = useRevealOnScroll(0.1);

  const anim = (delay = '') =>
    `transition-all duration-700 ease-out ${delay} ${revealed ? 'opacity-100 translate-y-0 blur-0' : 'opacity-0 translate-y-8 blur-md'}`;

  return (
    <section
      ref={ref}
      className="sm:p-8 sm:py-8 relative bg-white max-w-7xl border-black/5 border rounded-3xl mt-32 mr-auto mb-20 ml-auto pt-12 pr-6 pb-12 pl-6"
    >
      {/* Header */}
      <div className={`max-w-3xl mx-auto text-center ${anim()}`}>
        <h2 className="sm:text-5xl lg:text-6xl leading-[1.05] text-4xl font-medium text-neutral-900 tracking-tighter font-geist">
          Join our Impact Training Program
        </h2>
        <p className="sm:text-lg text-base text-neutral-600 mt-4 font-geist">
          Learn how to maximize your charitable impact and become a skilled changemaker. Transform your good intentions into measurable results.
        </p>
        <div className="mt-6 flex items-center justify-center gap-3">
          <a
            href="#enroll"
            className="inline-flex items-center gap-2 hover:bg-neutral-800 transition text-sm font-medium text-white font-geist bg-neutral-900 h-11 rounded-full pr-5 pl-5"
            style={{ boxShadow: deepShadow }}
          >
            Start Learning
            <iconify-icon icon="solar:arrow-right-linear" width="16" height="16"></iconify-icon>
          </a>
          <a href="#curriculum" className="inline-flex items-center justify-center h-11 px-5 rounded-full text-sm font-medium text-neutral-900 bg-white ring-1 ring-black/10 hover:bg-neutral-50 transition font-geist">
            View Programs
          </a>
        </div>
      </div>

      {/* Feature Cards */}
      <div className="mt-10 grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
        {cards.map((card, i) => (
          <article
            key={i}
            className={`bg-white rounded-3xl ring-1 ring-black/5 shadow-lg overflow-hidden ${anim(i === 0 ? 'delay-150' : i === 1 ? 'delay-300' : 'delay-[450ms]')}`}
          >
            <div className="bg-black rounded-2xl mx-4 mt-4 overflow-hidden">
              <img className="w-full h-48 object-cover" src={card.img} alt={card.alt} />
            </div>
            <div className="pt-5 pr-5 pb-5 pl-5">
              <h3 className="text-lg font-semibold tracking-tight text-neutral-900 font-geist">{card.title}</h3>
              <p className="text-sm text-neutral-600 mt-2 font-geist">{card.desc}</p>
            </div>
          </article>
        ))}
      </div>

      {/* Stats */}
      <div className={`mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 ${anim('delay-[600ms]')}`}>
        {stats.map((stat, i) => (
          <div key={i} className="bg-neutral-100/50 ring-black/5 ring-1 rounded-3xl pt-6 pr-6 pb-6 pl-6">
            <p className="text-3xl font-semibold tracking-tight text-neutral-900 font-geist">{stat.value}</p>
            <p className="text-sm text-neutral-600 mt-1 font-geist">{stat.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}