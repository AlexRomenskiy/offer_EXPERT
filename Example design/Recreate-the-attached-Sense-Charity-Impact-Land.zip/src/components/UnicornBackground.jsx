import React from 'react';
import UnicornScene from 'unicornstudio-react';

export default function UnicornBackground() {
  return (
    <div className="aura-background-component top-0 w-full -z-10 absolute h-[1000px]">
      <div className="absolute top-0 left-0 -z-10 w-full h-full">
        <UnicornScene projectId="ty3N7ZPaIU7KlWixQFIc" />
      </div>
    </div>
  );
}