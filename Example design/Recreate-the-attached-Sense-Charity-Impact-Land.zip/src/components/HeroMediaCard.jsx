import React from 'react';

const deepShadow =
  '0 2.8px 2.2px rgba(0,0,0,0.034), 0 6.7px 5.3px rgba(0,0,0,0.048), 0 12.5px 10px rgba(0,0,0,0.06), 0 22.3px 17.9px rgba(0,0,0,0.072), 0 41.8px 33.4px rgba(0,0,0,0.086), 0 100px 80px rgba(0,0,0,0.12)';

function MarqueeSet({ variant = 1 }) {
  const quoteAvatar = variant === 1
    ? 'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/12e9831e-2c6d-4dc7-bcd1-8537ce99de9d_320w.jpg'
    : 'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/dc8bd2b7-4838-4e1e-aa97-d9828c97ff57_320w.jpg';

  const teamAvatars = variant === 1
    ? [
        'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/133a6630-e785-43ed-bfa8-5066fe4bde1d_320w.jpg',
        'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/29fed605-bdd0-43de-9279-66c47c7319c2_320w.jpg',
        'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/acf4a275-4392-4642-8251-df704e9886a6_320w.jpg',
        'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/9db66d20-f0d3-4b6f-b063-df902515dc0b_320w.jpg',
      ]
    : [
        'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/d6b4b5b4-f90c-4254-9d80-bb0f199bd3bf_320w.jpg',
        'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/4feac9e0-d76c-4075-85a4-4dc143fa7c86_320w.jpg',
        'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/4f1d5b02-76dd-4df0-a8d1-8961b047a61a_320w.jpg',
        'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/90a93b05-a430-46df-b71f-1522700a6736_320w.jpg',
      ];

  const quoteTop = variant === 1 ? 'top-20 sm:top-64' : 'top-20 sm:top-24';
  const teamBottom = variant === 1 ? 'bottom-4 sm:bottom-32' : 'bottom-4 sm:bottom-6';
  const shadowStyle = variant === 1 ? { boxShadow: deepShadow } : {};

  return (
    <div className="relative sm:h-[760px] w-full h-[600px]">
      {/* Quote bubble */}
      <div className={`absolute left-4 sm:left-6 ${quoteTop} max-w-[260px] sm:max-w-xs`}>
        <div className="flex gap-3 sm:px-5 sm:py-4 ring-white/10 ring-1 bg-black/70 rounded-3xl pt-3 pr-4 pb-3 pl-4 backdrop-blur-md items-start" style={shadowStyle}>
          <img className="w-8 h-8 object-cover rounded-full" src={quoteAvatar} alt="Beneficiary avatar" />
          <p className="text-[13px] sm:text-sm leading-snug text-white/90 font-geist">"Because of Sense, I was given hope and a second chance."</p>
        </div>
      </div>

      {/* Watch reel */}
      <div className="absolute left-6 sm:left-10 top-1/2 -translate-y-1/2">
        <div className="flex gap-3 bg-black/70 ring-white/10 ring-1 rounded-full pt-2 pr-2 pb-2 pl-4 backdrop-blur-md items-center" style={shadowStyle}>
          <span className="text-[13px] sm:text-sm text-white/90 font-geist">Watch our story reel</span>
          <button className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-white text-black hover:bg-white/90 transition" aria-label="Play video">
            <iconify-icon icon="solar:play-linear" width="16" height="16"></iconify-icon>
          </button>
        </div>
      </div>

      {/* Bottom-left label */}
      <div className="absolute left-4 sm:left-6 bottom-6">
        <div className="px-3.5 py-2 rounded-full bg-black/70 backdrop-blur-md ring-1 ring-white/10 text-[12px] sm:text-xs text-white/90 shadow-sm font-geist">
          Real lives changed by your support
        </div>
      </div>

      {/* Bottom-right: Dedicated team */}
      <div className={`absolute right-4 sm:right-6 ${teamBottom} w-[230px] sm:w-[260px]`}>
        <div className="bg-black/70 ring-white/10 ring-1 rounded-3xl pt-4 pr-4 pb-4 pl-4 backdrop-blur-md" style={shadowStyle}>
          <p className="font-medium text-white mb-1 tracking-tight font-geist">Dedicated team</p>
          <p className="text-[13px] text-white/80 leading-snug mb-3 font-geist">
            Providing essential resources and aid to those who are in need in emergency.
          </p>
          <div className="flex items-center justify-between">
            <div className="flex -space-x-2">
              {teamAvatars.map((src, i) => (
                <img key={i} className="h-7 w-7 rounded-full ring-2 ring-black object-cover" src={src} alt={`Team avatar ${i + 1}`} />
              ))}
            </div>
            <div className="flex items-center gap-1 text-white/80">
              <iconify-icon icon="solar:users-group-rounded-linear" width="16" height="16"></iconify-icon>
              <span className="text-sm font-medium font-geist">50+</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function HeroMediaCard() {
  return (
    <div className="relative">
      <div
        className="relative overflow-hidden ring-1 ring-black/10 bg-neutral-50 rounded-[28px]"
        style={{ boxShadow: deepShadow }}
      >
        <div className="relative sm:h-[760px] h-[600px] overflow-hidden">
          <img
            src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/83622075-3856-42e4-b240-0a0d6f838a20_1600w.jpg"
            alt="Community volunteers"
            className="absolute inset-0 w-full h-full object-cover"
          />

          {/* Top-right nav-like pills */}
          <div className="absolute top-4 right-4 flex gap-2 z-20 items-center">
            <a href="#" className="sm:px-4 sm:text-sm hover:bg-black/70 transition ring-white/10 ring-1 text-xs text-white font-geist bg-black/60 rounded-full pt-2 pr-3 pb-2 pl-3 backdrop-blur-md">
              Donation
            </a>
            <a href="#" className="sm:px-4 ring-1 ring-white/10 sm:text-sm hover:bg-black/70 transition text-xs text-white font-geist bg-black/60 rounded-full pt-2 pr-3 pb-2 pl-3 backdrop-blur-md">
              Blogs
            </a>
            <a href="#" className="px-3 sm:px-4 py-2 rounded-full bg-black/75 backdrop-blur-md ring-1 ring-white/15 text-xs sm:text-sm text-white font-medium hover:bg-black/85 transition font-geist">
              Donate Now
            </a>
          </div>

          {/* Scrolling container with mask */}
          <div
            className="absolute inset-0"
            style={{
              maskImage: 'linear-gradient(to bottom, transparent, black 15%, black 85%, transparent)',
              WebkitMaskImage: 'linear-gradient(to bottom, transparent, black 15%, black 85%, transparent)',
            }}
          >
            <div className="animate-marquee-vertical">
              <MarqueeSet variant={1} />
              <MarqueeSet variant={2} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}