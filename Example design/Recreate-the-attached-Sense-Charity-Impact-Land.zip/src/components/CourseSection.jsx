import React from 'react';
import { useRevealOnScroll } from '../hooks/useRevealOnScroll';

const deepShadow =
  '0 2.8px 2.2px rgba(0,0,0,0.034), 0 6.7px 5.3px rgba(0,0,0,0.048), 0 12.5px 10px rgba(0,0,0,0.06), 0 22.3px 17.9px rgba(0,0,0,0.072), 0 41.8px 33.4px rgba(0,0,0,0.086), 0 100px 80px rgba(0,0,0,0.12)';

const modules = [
  { title: 'Module 1: Understanding Global Impact', desc: '4 hours, 2 case studies, 5 resources', delay: 'delay-[450ms]' },
  { title: 'Module 2: Strategic Philanthropy', desc: '5 hours, 3 projects, 4 resources', delay: 'delay-[550ms]' },
  { title: 'Module 3: Community Engagement', desc: '6 hours, 2 fieldwork, 6 resources', delay: 'delay-[650ms]' },
  { title: 'Module 4: Measuring Social Impact', desc: '4 hours, 1 capstone, 3 resources', delay: 'delay-[750ms]' },
  { title: 'Module 5: Volunteer Leadership', desc: '5 hours, 2 workshops, 4 resources', delay: 'delay-[850ms]' },
  { title: 'Module 6: Building Sustainable Change', desc: '6 hours, 1 capstone, 5 resources', delay: 'delay-[950ms]' },
];

const includes = [
  '30 hours comprehensive training',
  'Mentorship from experts',
  'Community network access',
  'Impact certification',
];

function CheckCircleIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600 mt-0.5 flex-shrink-0">
      <circle cx="12" cy="12" r="10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400 h-6 w-6 flex-shrink-0">
      <path d="M5 12h14" />
      <path d="M12 5v14" />
    </svg>
  );
}

export default function CourseSection() {
  const { ref, revealed } = useRevealOnScroll(0.1);

  const anim = (delay = '') =>
    `transition-all duration-700 ease-out ${delay} ${revealed ? 'opacity-100 translate-y-0 blur-0' : 'opacity-0 translate-y-8 blur-md'}`;

  return (
    <section className="sm:px-8 mt-20 mb-20" ref={ref}>
      <div className="sm:py-28 max-w-7xl mr-auto ml-auto pt-20 pb-20">
        <div className="sm:p-8 sm:py-8 bg-neutral-100/50 border-neutral-200/50 border rounded-3xl pt-6 pr-6 pb-6 pl-6">
          {/* Header */}
          <div className={`text-center ${anim()}`}>
            <span className="inline-flex items-center ring-1 ring-neutral-200 text-sm font-medium text-neutral-600 font-geist bg-white rounded-full pt-1 pr-3 pb-1 pl-3">
              Training Program
            </span>
            <h2 className="sm:text-5xl lg:text-6xl text-4xl font-normal text-neutral-900 tracking-tighter font-geist mt-4">
              Master impactful giving and volunteering
            </h2>
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10 mt-10 items-start">
            {/* Left: Program Card */}
            <div className={`lg:col-span-5 ${anim('delay-150')}`}>
              <div className="bg-white rounded-[28px] ring-1 ring-black/5 overflow-hidden shadow-lg">
                {/* Program header */}
                <div className="bg-blue-600 p-6 sm:p-8">
                  <p className="text-white/90 text-sm font-geist">Training Program</p>
                  <p className="mt-2 text-white text-5xl sm:text-6xl font-semibold tracking-tight font-geist">Free</p>
                  <p className="mt-2 text-white/80 text-sm font-geist">For all active Sense members</p>
                </div>

                {/* Program details */}
                <div className="p-5 sm:p-6">
                  <div className="sm:p-5 bg-neutral-100/50 ring-black/5 ring-1 rounded-2xl pt-4 pr-4 pb-4 pl-4">
                    <h3 className="text-neutral-900 font-semibold tracking-tight font-geist">
                      Impact Training: Maximizing Your Charitable Contribution
                    </h3>
                    <p className="text-neutral-700 text-sm mt-2 font-geist">
                      Learn evidence-based approaches to philanthropy and volunteering that create lasting positive change in communities.
                    </p>
                    <div className="mt-3 flex items-center gap-3">
                      <div className="flex -space-x-2">
                        <img className="ring-2 ring-white w-7 h-7 object-cover rounded-full" src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/e36aef18-f0f2-42d8-bcc3-86e5433f18f9_320w.jpg" alt="Participant 1" />
                        <img className="w-7 h-7 object-cover ring-white ring-2 rounded-full" src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/79e0a89c-b04e-4a65-b214-cc33e9601ecb_320w.jpg" alt="Participant 2" />
                        <img className="w-7 h-7 object-cover ring-white ring-2 rounded-full" src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/075e4814-03ac-46d1-bfeb-bb23651c0d08_320w.jpg" alt="Participant 3" />
                      </div>
                      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs text-neutral-700 ring-1 ring-black/10 font-geist">
                        500+ enrolled
                      </span>
                    </div>
                  </div>

                  {/* What's included */}
                  <div className="mt-6">
                    <p className="text-xs uppercase tracking-wider text-neutral-500 font-medium font-geist">What's included</p>
                    <ul className="mt-3 space-y-3">
                      {includes.map((item, i) => (
                        <li key={i} className="flex items-start gap-3 text-neutral-900 text-sm font-geist">
                          <CheckCircleIcon />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* CTA */}
                <div className="pr-5 pb-5 pl-5">
                  <a
                    href="#enroll"
                    className="inline-flex items-center justify-center hover:bg-neutral-800 transition text-sm font-medium text-white font-geist bg-neutral-900 w-full h-12 rounded-2xl"
                    style={{ boxShadow: deepShadow }}
                  >
                    Join Training Program
                    <iconify-icon icon="solar:arrow-right-linear" width="20" height="20" style={{ marginLeft: '8px' }}></iconify-icon>
                  </a>
                </div>
              </div>
            </div>

            {/* Center: Divider */}
            <div className={`lg:col-span-1 flex items-center justify-center ${anim('delay-300')}`}>
              <div className="h-full w-px bg-gradient-to-b from-transparent via-neutral-300 to-transparent min-h-96 hidden lg:block"></div>
              <div className="w-full h-px bg-gradient-to-r from-transparent via-neutral-300 to-transparent lg:hidden"></div>
            </div>

            {/* Right: Modules */}
            <div className="lg:col-span-6 space-y-4">
              {modules.map((mod, i) => (
                <React.Fragment key={i}>
                  <button
                    type="button"
                    className={`hover:bg-neutral-50 transition flex text-left bg-white w-full ring-black/5 ring-1 rounded-2xl pt-4 pr-5 pb-4 pl-5 shadow-lg items-center justify-between ${anim(mod.delay)}`}
                  >
                    <div className="min-w-0">
                      <p className="text-neutral-900 font-medium tracking-tight font-geist">{mod.title}</p>
                      <p className="text-neutral-600 text-sm mt-1 font-geist">{mod.desc}</p>
                    </div>
                    <PlusIcon />
                  </button>
                  {i < modules.length - 1 && (
                    <div className={`flex items-center px-5 ${anim(`delay-[${parseInt(mod.delay.match(/\d+/)[0]) + 50}ms]`)}`}>
                      <div className="flex-1 h-px bg-gradient-to-r from-transparent via-neutral-200 to-transparent"></div>
                    </div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}