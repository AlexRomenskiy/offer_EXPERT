import React from 'react';

const deepShadow =
  '0 2.8px 2.2px rgba(0,0,0,0.034), 0 6.7px 5.3px rgba(0,0,0,0.048), 0 12.5px 10px rgba(0,0,0,0.06), 0 22.3px 17.9px rgba(0,0,0,0.072), 0 41.8px 33.4px rgba(0,0,0,0.086), 0 100px 80px rgba(0,0,0,0.12)';

const programs = [
  {
    img: 'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/d8a18803-85b3-44b8-8ded-36a46f674b9c_800w.jpg',
    iconPath: 'M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5',
    tag: 'Healthcare Aid',
    title: 'HealthReach',
  },
  {
    img: 'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/fed1b639-6302-4656-940e-0f519fb2348b_800w.jpg',
    iconPaths: [
      'M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z',
      'M22 10v6',
      'M6 12.5V16a6 3 0 0 0 12 0v-3.5',
    ],
    tag: 'Education Access',
    title: 'LearnForward',
  },
  {
    img: 'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/c7e0c43a-8d25-4baf-aedb-f084dd7ecaa9_800w.jpg',
    iconPaths: [
      'M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z',
      'M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97',
    ],
    tag: 'Clean Water',
    title: 'WaterBridge',
  },
  {
    img: 'https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/a64e6770-50ba-4159-829d-d5f20fab2595_800w.jpg',
    iconPaths: [
      'M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8',
      'M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
    ],
    tag: 'Shelter Support',
    title: 'SafeHaven',
  },
];

function ProgramCard({ program }) {
  const paths = program.iconPath ? [program.iconPath] : program.iconPaths;
  return (
    <article className="relative overflow-hidden aspect-[4/3] bg-gradient-to-br from-zinc-800/50 to-zinc-900/50 border border-black/30 rounded-2xl">
      <div className="absolute inset-0 bg-cover" style={{ backgroundImage: `url(${program.img})` }}></div>
      <div className="absolute top-3 left-3">
        <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-zinc-100/90 text-zinc-900 border border-black/20">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5">
            {paths.map((d, i) => <path key={i} d={d} />)}
          </svg>
        </span>
      </div>
      <div className="absolute top-3 right-3">
        <span className="px-2 py-1 rounded-md bg-black/60 backdrop-blur text-[11px] text-zinc-300 font-normal border border-black/30 font-geist">
          {program.tag}
        </span>
      </div>
      <div className="absolute bottom-3 left-3 right-3">
        <p className="text-white text-lg font-medium tracking-tight leading-tight font-geist">{program.title}</p>
      </div>
    </article>
  );
}

export default function GlobalImpactSection() {
  return (
    <section
      className="sm:p-8 bg-neutral-950 max-w-7xl rounded-3xl mt-8 mr-auto ml-auto pt-6 pr-6 pb-6 pl-6"
      style={{ position: 'relative', overflow: 'hidden', boxShadow: deepShadow }}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-10 items-start relative z-10">
        {/* Left */}
        <div className="flex flex-col min-h-full justify-between">
          <div>
            <span className="text-sm font-normal text-zinc-300 font-geist">Global Impact Network</span>
            <h2 className="text-[44px] sm:text-6xl lg:text-7xl leading-[0.9] text-zinc-100 mt-2 font-geist font-medium tracking-tighter">
              Transforming communities worldwide.
            </h2>

            <div className="mt-8 relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full h-px bg-gradient-to-r from-black/5 via-black/10 to-black/5"></div>
              </div>
            </div>

            <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div>
                <p className="text-sm text-zinc-100 font-medium tracking-tight font-geist">Creating lasting change together</p>
                <p className="mt-1 text-sm text-zinc-300 font-geist">
                  Discover how our dedicated programs provide essential resources and support to communities in need across the globe.
                </p>
                <button className="mt-4 inline-flex items-center gap-2 h-10 px-4 rounded-full bg-zinc-100 text-zinc-900 text-sm font-normal hover:bg-zinc-200 transition font-geist">
                  View Our Programs
                  <span className="inline-flex h-2 w-2 rounded-full bg-zinc-900"></span>
                </button>
              </div>

              <div className="relative">
                <div className="absolute left-0 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-black/10 to-transparent sm:block hidden"></div>
                <p className="text-base text-zinc-200 leading-relaxed sm:text-right sm:pl-8 font-geist">
                  Our comprehensive approach combines{' '}
                  <span className="font-medium text-zinc-100 font-geist">humanitarian excellence</span>{' '}
                  with sustainable solutions that grow with community needs.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Marquee Program grid */}
        <div
          className="relative h-[520px] overflow-hidden"
          style={{
            maskImage: 'linear-gradient(to bottom, transparent, black 15%, black 85%, transparent)',
            WebkitMaskImage: 'linear-gradient(to bottom, transparent, black 15%, black 85%, transparent)',
          }}
        >
          <div className="animate-marquee-vertical-programs">
            <div className="grid grid-cols-2 gap-4 mb-4">
              {programs.map((p, i) => (
                <ProgramCard key={i} program={p} />
              ))}
            </div>
            <div className="grid grid-cols-2 gap-4">
              {programs.map((p, i) => (
                <ProgramCard key={`dup-${i}`} program={p} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}