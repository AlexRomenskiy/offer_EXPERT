import React, { useState, useEffect, useRef } from 'react';

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const buttonRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(e.target) &&
        buttonRef.current &&
        !buttonRef.current.contains(e.target)
      ) {
        setMenuOpen(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) setMenuOpen(false);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <header className="relative">
      <div className="lg:px-8 max-w-7xl mr-auto ml-auto pr-6 pl-6">
        <div className="flex pt-8 pb-8 items-center justify-between">
          {/* Brand */}
          <a
            href="/"
            className="inline-flex items-center justify-center bg-center mix-blend-multiply w-[130px] h-[40px] bg-cover rounded invert"
            style={{
              backgroundImage:
                'url(https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/cabcb3dd-d3a2-48fd-9b67-55ddd5de69ce_800w.jpg)',
            }}
          ></a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6 text-sm text-neutral-600">
            <a href="/about" className="hover:text-neutral-900 transition-colors font-geist">What We Do</a>
            <a href="/causes" className="hover:text-neutral-900 transition-colors font-geist">Causes</a>
            <a href="/team" className="hover:text-neutral-900 transition-colors font-geist">Team</a>
            <a href="/blogs" className="hover:text-neutral-900 transition-colors font-geist">Blogs</a>
            <a
              href="/pricing"
              className="inline-flex items-center gap-2 hover:bg-neutral-800 transition-colors font-medium text-white font-geist bg-neutral-900 rounded-full pt-2 pr-4 pb-2 pl-4"
              style={{
                boxShadow:
                  '0 2.8px 2.2px rgba(0,0,0,0.034), 0 6.7px 5.3px rgba(0,0,0,0.048), 0 12.5px 10px rgba(0,0,0,0.06), 0 22.3px 17.9px rgba(0,0,0,0.072), 0 41.8px 33.4px rgba(0,0,0,0.086), 0 100px 80px rgba(0,0,0,0.12)',
              }}
            >
              Donate Now
              <iconify-icon icon="solar:arrow-right-linear" width="16" height="16"></iconify-icon>
            </a>
          </nav>

          {/* Mobile Menu Button */}
          <button
            ref={buttonRef}
            className="md:hidden inline-flex hover:bg-neutral-100 transition-colors bg-neutral-50 w-10 h-10 rounded-full items-center justify-center"
            aria-label="Toggle menu"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {!menuOpen ? (
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-900">
                <path d="M3 12h18" />
                <path d="M3 6h18" />
                <path d="M3 18h18" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-900">
                <path d="M18 6 6 18" />
                <path d="M6 6l12 12" />
              </svg>
            )}
          </button>
        </div>

        {/* Mobile Navigation Menu */}
        <div
          ref={menuRef}
          className={`md:hidden absolute top-full left-0 right-0 bg-white border-t border-neutral-200 shadow-lg z-50 ${menuOpen ? '' : 'hidden'}`}
        >
          <nav className="pt-6 pr-6 pb-6 pl-6 space-y-4">
            <a href="/about" className="block hover:text-neutral-900 transition-colors text-base text-neutral-600 font-geist pt-2 pb-2">What We Do</a>
            <a href="/causes" className="block hover:text-neutral-900 transition-colors text-base text-neutral-600 font-geist pt-2 pb-2">Causes</a>
            <a href="/team" className="block hover:text-neutral-900 transition-colors text-base text-neutral-600 font-geist pt-2 pb-2">Team</a>
            <a href="/blogs" className="block hover:text-neutral-900 transition-colors text-base text-neutral-600 font-geist pt-2 pb-2">Blogs</a>
            <div className="pt-4 border-t border-neutral-200">
              <a
                href="/pricing"
                className="inline-flex items-center gap-2 hover:bg-neutral-800 transition-colors justify-center font-medium text-white font-geist bg-neutral-900 w-full rounded-full pt-3 pr-4 pb-3 pl-4"
                style={{
                  boxShadow:
                    '0 2.8px 2.2px rgba(0,0,0,0.034), 0 6.7px 5.3px rgba(0,0,0,0.048), 0 12.5px 10px rgba(0,0,0,0.06), 0 22.3px 17.9px rgba(0,0,0,0.072), 0 41.8px 33.4px rgba(0,0,0,0.086), 0 100px 80px rgba(0,0,0,0.12)',
                }}
              >
                Donate Now
                <iconify-icon icon="solar:arrow-right-linear" width="16" height="16"></iconify-icon>
              </a>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
}