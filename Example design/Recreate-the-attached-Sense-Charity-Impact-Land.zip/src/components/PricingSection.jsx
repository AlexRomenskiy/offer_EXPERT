import React from 'react';

const deepShadow =
  '0 2.8px 2.2px rgba(0,0,0,0.034), 0 6.7px 5.3px rgba(0,0,0,0.048), 0 12.5px 10px rgba(0,0,0,0.06), 0 22.3px 17.9px rgba(0,0,0,0.072), 0 41.8px 33.4px rgba(0,0,0,0.086), 0 100px 80px rgba(0,0,0,0.12)';

function CheckIcon({ className = 'text-green-600' }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`flex-shrink-0 ${className}`}>
      <path d="M20 6 9 17l-5-5" />
    </svg>
  );
}

const plans = [
  {
    name: 'Helper',
    subtitle: 'Basic support',
    price: '$25',
    desc: 'Perfect for individual contributors who want to make a consistent impact',
    features: ['Monthly impact reports', 'Community newsletter', 'Digital thank you card'],
    cta: 'Start Helping',
    iconBg: 'bg-blue-100',
    iconColor: 'text-blue-600',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 text-blue-600">
        <path d="M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5" />
      </svg>
    ),
    featured: false,
  },
  {
    name: 'Supporter',
    subtitle: 'Enhanced impact',
    price: '$75',
    desc: 'Ideal for those ready to make a more substantial difference in communities',
    features: ['Everything in Helper', 'Quarterly video updates', 'Priority support access', 'Community forum access'],
    cta: 'Become Supporter',
    iconBg: 'bg-green-100',
    iconColor: 'text-green-600',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 text-green-600">
        <path d="M5 12h14" /><path d="M12 5v14" />
      </svg>
    ),
    featured: false,
  },
  {
    name: 'Champion',
    subtitle: 'Maximum impact',
    price: '$150',
    desc: 'For dedicated supporters who want to drive significant change and lead by example',
    features: ['Everything in Supporter', '1-on-1 impact calls', 'Project naming rights', 'Exclusive event invites', 'Annual impact certificate'],
    cta: 'Join Champions',
    iconBg: 'bg-white',
    iconColor: 'text-blue-700',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 text-blue-700">
        <path d="M10 14.66v1.626a2 2 0 0 1-.976 1.696A5 5 0 0 0 7 21.978" /><path d="M14 14.66v1.626a2 2 0 0 0 .976 1.696A5 5 0 0 1 17 21.978" /><path d="M18 9h1.5a1 1 0 0 0 0-5H18" /><path d="M4 22h16" /><path d="M6 9a6 6 0 0 0 12 0V3a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1z" /><path d="M6 9H4.5a1 1 0 0 1 0-5H6" />
      </svg>
    ),
    featured: true,
  },
  {
    name: 'Leader',
    subtitle: 'Ultimate partnership',
    price: '$500',
    desc: 'For organizations and individuals who want to transform entire communities',
    features: ['Everything in Champion', 'Custom project development', 'Dedicated account manager', 'Site visit opportunities', 'Leadership board recognition'],
    cta: 'Lead Change',
    iconBg: 'bg-amber-100',
    iconColor: 'text-amber-600',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 text-amber-600">
        <path d="m11 17 2 2a1 1 0 1 0 3-3" /><path d="m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4" /><path d="m21 3 1 11h-2" /><path d="M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3" /><path d="M3 4h8" />
      </svg>
    ),
    featured: false,
  },
];

export default function PricingSection() {
  return (
    <section className="lg:px-8 lg:py-24 sm:px-8 mt-20 mb-20 pt-20 pr-6 pb-20 pl-6">
      <div className="text-center mb-16">
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-medium tracking-tight mb-6 font-geist">
          Choose Your Impact Level
        </h2>
        <p className="text-neutral-600 text-lg leading-relaxed max-w-2xl mx-auto font-geist">
          Every contribution makes a difference. Select a plan that matches your commitment to creating positive change in communities worldwide.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
        {plans.map((plan, i) => {
          if (plan.featured) {
            return (
              <div
                key={i}
                className="relative bg-blue-700 rounded-[32px] pt-8 pr-8 pb-8 pl-8 transition-all duration-700 ease-out delay-300"
                style={{
                  boxShadow: 'rgba(255, 255, 255, 0.1) 0px 1px 1px 0px inset, rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px',
                }}
              >
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div
                    className="text-xs font-medium text-blue-700 font-geist bg-white border-black/10 border rounded-full pt-1.5 pr-4 pb-1.5 pl-4"
                    style={{ boxShadow: deepShadow }}
                  >
                    Most Popular
                  </div>
                </div>

                <div className="flex items-center gap-3 mb-6">
                  <div className={`h-12 w-12 rounded-full ${plan.iconBg} flex items-center justify-center`}>
                    {plan.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-medium text-white font-geist">{plan.name}</h3>
                    <p className="text-sm text-blue-200 font-geist">{plan.subtitle}</p>
                  </div>
                </div>

                <div className="mb-6">
                  <div className="flex items-baseline gap-1 mb-2">
                    <span className="text-3xl font-medium text-white font-geist">{plan.price}</span>
                    <span className="text-blue-200 text-sm font-geist">/month</span>
                  </div>
                  <p className="text-sm text-blue-100 font-geist">{plan.desc}</p>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((f, j) => (
                    <li key={j} className="flex items-center gap-3 text-sm text-white font-geist">
                      <CheckIcon className="text-blue-200" />
                      {f}
                    </li>
                  ))}
                </ul>

                <a
                  href="#"
                  className="inline-flex items-center justify-center hover:bg-white/90 transition-colors font-medium text-blue-700 font-geist bg-white w-full rounded-full pt-3 pr-6 pb-3 pl-6"
                  style={{ boxShadow: deepShadow }}
                >
                  {plan.cta}
                </a>
              </div>
            );
          }

          return (
            <div
              key={i}
              className="relative bg-white rounded-[32px] p-8 ring-1 ring-neutral-200 hover:ring-neutral-300 hover:shadow-[0_2.8px_2.2px_rgba(0,0,0,0.034),0_6.7px_5.3px_rgba(0,0,0,0.048),0_12.5px_10px_rgba(0,0,0,0.06)] transition-all duration-700 ease-out"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className={`h-12 w-12 rounded-full ${plan.iconBg} flex items-center justify-center`}>
                  {plan.icon}
                </div>
                <div>
                  <h3 className="text-xl font-medium text-neutral-900 font-geist">{plan.name}</h3>
                  <p className="text-sm text-neutral-500 font-geist">{plan.subtitle}</p>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex items-baseline gap-1 mb-2">
                  <span className="text-3xl font-medium text-neutral-900 font-geist">{plan.price}</span>
                  <span className="text-neutral-500 text-sm font-geist">/month</span>
                </div>
                <p className="text-sm text-neutral-600 font-geist">{plan.desc}</p>
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((f, j) => (
                  <li key={j} className="flex items-center gap-3 text-sm text-neutral-700 font-geist">
                    <CheckIcon />
                    {f}
                  </li>
                ))}
              </ul>

              <a
                href="#"
                className="inline-flex items-center justify-center hover:bg-neutral-800 transition-colors font-medium text-white font-geist bg-neutral-900 w-full rounded-full pt-3 pr-6 pb-3 pl-6"
                style={{ boxShadow: deepShadow }}
              >
                {plan.cta}
              </a>
            </div>
          );
        })}
      </div>

      <div className="text-center mt-12">
        <p className="text-neutral-600 mb-6 font-geist">Need a custom solution? We're here to help.</p>
        <a href="#" className="inline-flex items-center gap-2 text-neutral-900 font-medium hover:opacity-80 transition-opacity font-geist">
          Contact Our Team
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M7 17L17 7" />
            <path d="M7 7h10v10" />
          </svg>
        </a>
      </div>
    </section>
  );
}