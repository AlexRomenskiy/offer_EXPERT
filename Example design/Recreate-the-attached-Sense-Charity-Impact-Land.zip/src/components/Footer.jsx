import React, { useState } from 'react';

const footerLinks = {
  Programs: [
    { label: 'HealthReach', href: '#health' },
    { label: 'LearnForward', href: '#education' },
    { label: 'WaterBridge', href: '#water' },
    { label: 'SafeHaven', href: '#shelter' },
  ],
  'Get Involved': [
    { label: 'Donate Now', href: '#donate' },
    { label: 'Volunteer', href: '#volunteer' },
    { label: 'Partner', href: '#partner' },
    { label: 'Fundraise', href: '#fundraise' },
  ],
  About: [
    { label: 'Our Mission', href: '#mission' },
    { label: 'Impact Stories', href: '#impact' },
    { label: 'Transparency', href: '#transparency' },
    { label: 'Careers', href: '#careers' },
  ],
};

export default function Footer() {
  const [email, setEmail] = useState('');

  return (
    <footer className="sm:px-8 pt-16 pb-12">
      <div className="relative overflow-hidden bg-white border border-black/5 rounded-3xl">
        <div className="relative z-10 sm:p-8 md:p-12 pt-8 pr-4 pb-8 pl-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-12 pb-12">
            <div className="lg:col-span-4">
              {/* Logo */}
              <div className="flex gap-3 mb-6 items-center">
                <a
                  href="#"
                  className="inline-flex items-center justify-center bg-center mix-blend-screen w-[160px] h-[40px] bg-cover rounded invert"
                  style={{
                    backgroundImage:
                      'url(https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/cabcb3dd-d3a2-48fd-9b67-55ddd5de69ce_320w.jpg)',
                  }}
                ></a>
              </div>
              <p className="text-xl text-black/70 font-geist max-w-3xl mb-10">
                Creating lasting change together. Join our mission to transform communities worldwide through compassionate action and sustainable support.
              </p>

              {/* Dark newsletter + links section */}
              <div className="sm:p-8 md:p-12 bg-gradient-to-b from-neutral-800 to-neutral-950 border-black/5 border rounded-3xl pt-6 pr-6 pb-6 pl-6 shadow-xl">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Newsletter */}
                  <div className="space-y-6">
                    <div className="inline-flex items-center gap-2 rounded-full bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/20 px-3 py-2 text-sm font-geist">
                      <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      Impact updates, free
                    </div>
                    <h4 className="text-2xl font-semibold text-white tracking-tight font-geist">Stay connected</h4>
                    <ul className="space-y-3 text-base text-white/70">
                      {['Monthly impact reports and stories.', 'Volunteer opportunities near you.', 'No spam, unsubscribe anytime.'].map((item, i) => (
                        <li key={i} className="flex items-start gap-3 font-geist">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4 text-emerald-400 mt-1 flex-shrink-0">
                            <path d="M20 6 9 17l-5-5" />
                          </svg>
                          {item}
                        </li>
                      ))}
                    </ul>
                    <form className="flex gap-3 pt-2" onSubmit={(e) => e.preventDefault()}>
                      <input
                        type="email"
                        required
                        placeholder="your.email@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="flex-1 h-12 px-4 rounded-xl border border-white/20 bg-black/20 text-sm placeholder-white/40 text-white outline-none focus:ring-2 focus:ring-white/20 focus:border-white/40 backdrop-blur"
                      />
                      <button className="inline-flex items-center gap-2 h-12 px-5 rounded-xl ring-1 ring-white/20 text-sm text-white bg-black/20 hover:bg-white hover:text-black transition font-geist">
                        Join
                      </button>
                    </form>
                  </div>

                  {/* Links */}
                  <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-8">
                    {Object.entries(footerLinks).map(([category, links]) => (
                      <div key={category}>
                        <h5 className="text-white/80 text-xs uppercase tracking-wider font-medium font-geist mb-4">{category}</h5>
                        <ul className="space-y-3 text-base text-white/70">
                          {links.map((link) => (
                            <li key={link.label}>
                              <a className="hover:text-white transition font-geist" href={link.href}>{link.label}</a>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom bar */}
              <div className="mt-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
                <div className="flex items-center gap-4 text-base text-black/60">
                  <span className="font-geist">© 2025 Sense</span>
                  <span className="hidden sm:inline text-black/20 font-geist">|</span>
                  <a href="#privacy" className="hover:text-black transition font-geist">Privacy</a>
                  <span className="text-black/20 font-geist">/</span>
                  <a href="#terms" className="hover:text-black transition font-geist">Terms</a>
                </div>
                <div className="flex items-center gap-3">
                  <a
                    aria-label="Instagram"
                    className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-black/5 text-black/70 hover:text-black hover:bg-black/10 transition"
                    href="https://instagram.com"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <iconify-icon icon="simple-icons:instagram" width="20" height="20"></iconify-icon>
                  </a>
                  <a
                    aria-label="Twitter/X"
                    className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-black/5 text-black/70 hover:text-black hover:bg-black/10 transition"
                    href="https://twitter.com"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <iconify-icon icon="simple-icons:x" width="20" height="20"></iconify-icon>
                  </a>
                  <a
                    aria-label="YouTube"
                    className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-black/5 text-black/70 hover:text-black hover:bg-black/10 transition"
                    href="https://youtube.com"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <iconify-icon icon="simple-icons:youtube" width="20" height="20"></iconify-icon>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}