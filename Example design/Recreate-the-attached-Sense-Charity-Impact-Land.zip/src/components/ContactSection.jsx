import React, { useState } from 'react';

export default function ContactSection() {
  const [formData, setFormData] = useState({ email: '', organization: '', message: '' });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  const highlights = [
    { title: 'Join 1,000+ donors', desc: 'Connect with a community of active contributors making real change happen.' },
    { title: 'Global impact', desc: 'Your support reaches communities across 50+ countries worldwide.' },
    { title: 'Track your impact', desc: 'Receive detailed reports showing exactly how your contribution helps.' },
    { title: '100% transparent', desc: 'Every dollar is tracked with full transparency and accountability.' },
  ];

  return (
    <section className="bg-white mt-10">
      <div className="relative overflow-hidden mt-40 mb-20">
        <div className="relative z-10 lg:px-8 sm:px-8 max-w-7xl mr-auto ml-auto pt-16 pr-6 pb-16 pl-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Form card */}
            <div className="lg:col-span-6">
              <div className="sm:p-8 bg-neutral-50 ring-neutral-200 ring-1 rounded-[32px] pt-6 pr-6 pb-6 pl-6 shadow-lg">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <p className="text-sm text-neutral-500 font-geist">Sense Partnership</p>
                    <h3 className="mt-2 text-3xl sm:text-4xl font-medium tracking-tight text-neutral-900 font-geist">
                      Ready to create impact?
                    </h3>
                  </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label htmlFor="ct-email" className="block text-sm text-neutral-700 mb-2 font-geist">
                      Email address<span className="text-neutral-400"> *</span>
                    </label>
                    <div className="relative">
                      <iconify-icon icon="solar:letter-linear" width="20" height="20" style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#a3a3a3' }}></iconify-icon>
                      <input
                        id="ct-email"
                        name="email"
                        type="email"
                        required
                        placeholder="your.email@example.com"
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full pl-12 pr-4 py-3 text-base rounded-2xl ring-1 ring-neutral-200 focus:ring-2 focus:ring-neutral-900 outline-none bg-white placeholder:text-neutral-400 font-geist"
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="ct-org" className="block text-sm text-neutral-700 mb-2 font-geist">Organization</label>
                    <input
                      id="ct-org"
                      name="organization"
                      type="text"
                      placeholder="Company or organization name"
                      value={formData.organization}
                      onChange={handleChange}
                      className="w-full pl-4 pr-4 py-3 text-base rounded-2xl ring-1 ring-neutral-200 focus:ring-2 focus:ring-neutral-900 outline-none bg-white placeholder:text-neutral-400 font-geist"
                    />
                  </div>
                  <div>
                    <label htmlFor="ct-msg" className="block text-sm text-neutral-700 mb-2 font-geist">
                      How would you like to contribute?
                    </label>
                    <textarea
                      id="ct-msg"
                      name="message"
                      rows="4"
                      placeholder="Share your ideas for partnership, volunteering, or donation plans..."
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full resize-y pl-4 pr-4 py-3 text-base rounded-2xl ring-1 ring-neutral-200 focus:ring-2 focus:ring-neutral-900 outline-none bg-white placeholder:text-neutral-400 font-geist"
                    />
                  </div>
                  <button
                    type="submit"
                    className="inline-flex hover:bg-neutral-800 transition-colors text-base font-medium text-white font-geist bg-neutral-900 w-full rounded-2xl pt-4 pr-6 pb-4 pl-6 items-center justify-center"
                  >
                    Start Making a Difference
                    <iconify-icon icon="solar:arrow-right-linear" width="20" height="20" style={{ marginLeft: '8px' }}></iconify-icon>
                  </button>
                  <p className="text-sm text-neutral-500 font-geist">
                    By submitting, you agree to join our mission and our Terms &amp; Privacy Policy.
                  </p>
                </form>
              </div>
            </div>

            {/* Copy + highlights */}
            <div className="lg:col-span-6">
              <div className="max-w-xl">
                <div className="flex gap-3 mt-6 mb-6 items-center">
                  <div className="flex -space-x-2">
                    <img className="w-7 h-7 object-cover ring-white ring-2 rounded-full" src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/5aa0d46a-9a98-4044-bce9-68ec849538ef_320w.jpg" alt="Member avatar 1" />
                    <img className="w-7 h-7 object-cover ring-white ring-2 rounded-full" src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/a847bbaa-3964-40c8-ad91-98b3d6429867_320w.jpg" alt="Member avatar 2" />
                    <img className="w-7 h-7 object-cover ring-white ring-2 rounded-full" src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/054cd9f9-ea66-4ac7-8e45-659730cfc5a3_320w.jpg" alt="Member avatar 3" />
                  </div>
                  <p className="text-sm text-neutral-600 font-geist">
                    <span className="font-medium text-neutral-900 font-geist">1000+</span> donor active members
                  </p>
                </div>

                <h2 className="sm:text-6xl leading-[1.05] text-5xl font-medium text-neutral-900 tracking-tight font-geist">
                  Partner with purpose.
                </h2>
                <p className="sm:text-lg text-base text-neutral-600 mt-6 leading-relaxed font-geist">
                  Join thousands of changemakers who are transforming communities worldwide. Whether through donations, volunteering, or corporate partnerships—every contribution creates lasting impact.
                </p>

                <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {highlights.map((h, i) => (
                    <div key={i} className="flex items-start gap-4">
                      <div>
                        <p className="text-neutral-900 font-medium text-base font-geist">{h.title}</p>
                        <p className="text-neutral-600 text-sm mt-1 font-geist">{h.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Direct contact card */}
                <div className="mt-8">
                  <div className="inline-flex items-center gap-4 rounded-[28px] bg-white ring-1 ring-neutral-200 shadow-lg p-4">
                    <img
                      src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/201c453d-d501-4246-98c0-bdc43ce733a8_320w.jpg"
                      alt="Partnership lead"
                      className="w-14 h-14 object-cover rounded-2xl"
                    />
                    <div className="min-w-0">
                      <p className="text-sm text-neutral-500 leading-none font-geist">Partnership Lead</p>
                      <p className="text-neutral-900 font-medium tracking-tight truncate mt-1 text-lg font-geist">Sarah Chen</p>
                      <p className="text-neutral-600 text-sm font-geist">Available Mon-Fri, 9am-5pm EST</p>
                    </div>
                    <a
                      href="mailto:partnerships@sense.org"
                      className="ml-2 inline-flex items-center gap-2 rounded-2xl bg-neutral-900 text-white px-4 py-3 text-sm font-medium hover:bg-neutral-800 transition-colors font-geist"
                    >
                      Schedule a call
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}