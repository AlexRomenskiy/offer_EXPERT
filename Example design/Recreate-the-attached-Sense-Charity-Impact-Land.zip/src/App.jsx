import React from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import TrainingProgramSection from './components/TrainingProgramSection';
import CourseSection from './components/CourseSection';
import PricingSection from './components/PricingSection';
import GlobalImpactSection from './components/GlobalImpactSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import UnicornBackground from './components/UnicornBackground';

export default function App() {
  return (
    <>
      <UnicornBackground />
      <Header />
      <main>
        <HeroSection />
        <TrainingProgramSection />
        <CourseSection />
        <PricingSection />
        <GlobalImpactSection />
        <ContactSection />
        <Footer />
      </main>
    </>
  );
}